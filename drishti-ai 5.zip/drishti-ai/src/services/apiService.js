// ============================================
// DRISHTI - API Service
// ✅ BYOK ON → User की key
// ✅ BYOK OFF → Backend Engine
// ✅ Voice System - दादी, मां, दीदी etc.
// ============================================

const BACKEND_URL = 'https://your-app.onrender.com';
const FREE_MESSAGES_PER_DAY = 20;

// ============================================
// MAIN FUNCTION
// ============================================
export const sendMessage = async (message, history = []) => {
  const byokOn = localStorage.getItem('byok_enabled') === 'true';
  const keysRaw = localStorage.getItem('byok_keys');
  const slots = keysRaw ? JSON.parse(keysRaw) : [];
  const activeSlots = slots.filter(s => s.active && s.apiKey);

  if (byokOn && activeSlots.length > 0) {
    return await callWithBYOK(message, history, activeSlots);
  }
  return await callBackend(message, history);
};

// ============================================
// BYOK CALL
// ============================================
const callWithBYOK = async (message, history, activeSlots) => {
  for (const slot of activeSlots) {
    try {
      const provider = (slot.providerName || '').toLowerCase();
      const key = slot.apiKey;

      if (provider.includes('claude') || key.startsWith('sk-ant-')) {
        const res = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'x-api-key': key,
            'anthropic-version': '2023-06-01',
          },
          body: JSON.stringify({
            model: 'claude-haiku-4-5-20251001',
            max_tokens: 800,
            messages: [{ role: 'user', content: message }],
          }),
        });
        const data = await res.json();
        return { text: data.content[0].text, source: 'byok' };
      }

      if (provider.includes('gemini') || key.startsWith('AIza')) {
        const res = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${key}`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              contents: [{ parts: [{ text: message }] }],
            }),
          }
        );
        const data = await res.json();
        return {
          text: data.candidates[0].content.parts[0].text,
          source: 'byok',
        };
      }

      const res = await fetch(
        'https://api.groq.com/openai/v1/chat/completions',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${key}`,
          },
          body: JSON.stringify({
            model: slot.detectedModel || 'llama-3.1-8b-instant',
            messages: [
              {
                role: 'system',
                content:
                  'तुम DRISHTI हो - Hindi AI Assistant। Hindi में जवाब दो। Short और helpful रहो।',
              },
              ...history,
              { role: 'user', content: message },
            ],
            max_tokens: 800,
          }),
        }
      );
      const data = await res.json();
      return { text: data.choices[0].message.content, source: 'byok' };

    } catch (e) {
      continue;
    }
  }
  return {
    text: 'API key से connect नहीं हो पाया। Settings में check करो। 🔑',
    source: 'error',
  };
};

// ============================================
// BACKEND CALL
// ============================================
const callBackend = async (message, history) => {
  const today = new Date().toDateString();
  const usageKey = `usage_${today}`;
  const used = parseInt(localStorage.getItem(usageKey) || '0');

  if (used >= FREE_MESSAGES_PER_DAY) {
    return {
      text: `आज के ${FREE_MESSAGES_PER_DAY} free messages पूरे हो गए! 🔑 Settings → My APIs में अपनी key add करो unlimited के लिए।`,
      source: 'limit',
      limitReached: true,
    };
  }

  if (!BACKEND_URL || BACKEND_URL.includes('your-app')) {
    return getFallback(message);
  }

  try {
    const res = await fetch(`${BACKEND_URL}/api/chat`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, history }),
    });
    if (!res.ok) throw new Error('Backend error');
    const data = await res.json();
    localStorage.setItem(usageKey, (used + 1).toString());
    return {
      text: data.reply,
      source: 'backend',
      remaining: FREE_MESSAGES_PER_DAY - used - 1,
    };
  } catch (e) {
    return getFallback(message);
  }
};

// ============================================
// FALLBACK
// ============================================
const getFallback = (message) => {
  const t = message.toLowerCase();
  if (t.includes('नमस्ते') || t.includes('hello') || t.includes('hi'))
    return {
      text: 'नमस्ते! 😊 Settings में API key add करो बेहतर जवाब के लिए!',
      source: 'fallback',
    };
  if (t.includes('upi') || t.includes('payment'))
    return {
      text: 'UPI Payment:\n1. GPay खोलो\n2. Pay दबाओ\n3. Number डालो\n4. Amount डालो\n5. PIN डालो ✅',
      source: 'fallback',
    };
  if (t.includes('whatsapp'))
    return {
      text: 'WhatsApp:\n1. Chat खोलो\n2. 📎 दबाओ\n3. File चुनो\n4. Send करो ✅',
      source: 'fallback',
    };
  return {
    text: 'Settings → My APIs में Groq की free key add करो!\nconsole.groq.com पर free account बनाओ। 🔑',
    source: 'fallback',
  };
};

// ============================================
// VOICE SYSTEM
// ============================================
const VOICE_CONFIGS = {
  dadi: {
    rate: 0.65,
    pitch: 1.4,
    lang: 'hi-IN',
    name: 'दादी 👵',
    desc: 'धीमी, मीठी आवाज़',
  },
  maa: {
    rate: 0.78,
    pitch: 1.25,
    lang: 'hi-IN',
    name: 'मां 👩',
    desc: 'प्यार भरी आवाज़',
  },
  didi: {
    rate: 0.95,
    pitch: 1.15,
    lang: 'hi-IN',
    name: 'दीदी 👧',
    desc: 'Friendly, caring',
  },
  bhai: {
    rate: 1.0,
    pitch: 0.82,
    lang: 'hi-IN',
    name: 'भाई 👦',
    desc: 'Cool, casual',
  },
  teacher: {
    rate: 0.88,
    pitch: 1.0,
    lang: 'hi-IN',
    name: 'Teacher 👩‍🏫',
    desc: 'Clear, formal',
  },
  nana: {
    rate: 0.6,
    pitch: 1.3,
    lang: 'hi-IN',
    name: 'नाना 👴',
    desc: 'Slow, warm',
  },
};

export const speakText = (text, voiceType = 'didi') => {
  if (!('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();

  const config = VOICE_CONFIGS[voiceType] || VOICE_CONFIGS.didi;
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = config.lang;
  utterance.rate = config.rate;
  utterance.pitch = config.pitch;

  const loadVoice = () => {
    const allVoices = window.speechSynthesis.getVoices();
    const hindiVoice = allVoices.find(
      v => v.lang.includes('hi') || v.lang.includes('IN')
    );
    if (hindiVoice) utterance.voice = hindiVoice;
    window.speechSynthesis.speak(utterance);
  };

  if (window.speechSynthesis.getVoices().length > 0) {
    loadVoice();
  } else {
    window.speechSynthesis.onvoiceschanged = loadVoice;
  }
};

export const stopVoice = () => {
  if ('speechSynthesis' in window) window.speechSynthesis.cancel();
};

export const getSelectedVoice = () => {
  return localStorage.getItem('selectedVoice') || 'didi';
};

export const getAllVoices = () => VOICE_CONFIGS;
