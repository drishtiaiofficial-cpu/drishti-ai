// config.js
// ✅ बस यही एक file change करो जब backend ready हो

export const CONFIG = {
  // तुम्हारा Render backend URL
  // जब ready हो तो यहाँ paste करो
  BACKEND_URL: 'https://your-app.onrender.com',

  // Rate limits
  FREE_MESSAGES_PER_DAY: 20,
  PRO_MESSAGES_PER_DAY: 999,
};

